F.R.I.E.N.D. Working Final App

Open this first:
  preview.html

Use this as the clean app file:
  index.html

This package is intentionally all-in-one:
- No external CSS files
- No external JavaScript files
- No missing image files
- King Soopers logo is embedded
- Works by double-clicking on Mac after unzipping

Important presentation match:
- Guided Temperature Mission shows 171°F actual temperature
- Target temperature is 165°F or above
- Alex is the associate workflow
- Jamie/Joey leader flow remains interactive
